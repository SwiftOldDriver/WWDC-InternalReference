//
//  Content_ScrollBasic.swift
//  WWDC23-10159
//
//  Created by Catherine on 2023/6/16.
//

import SwiftUI

struct Item: Identifiable {
    var id: Int
}

struct Content_ScrollBasic: View {
    @State var items: [Item] = (1 ... 50).map { Item(id: $0) }

    var body: some View {
        ScrollView(.vertical) {
            LazyVStack {
                ForEach(items) { item in
                    ItemView(item: item)
                }
            }
        }
    }
}

struct ItemView: View {
    var item: Item

    init(item: Item) {
        print("   Item init: \(item.id)")
        self.item = item
    }

    var body: some View {
        Text(item.id, format: .number)
            .padding(.vertical)
            .frame(maxWidth: .infinity)
    }
}

#Preview {
    Content_ScrollBasic()
}
