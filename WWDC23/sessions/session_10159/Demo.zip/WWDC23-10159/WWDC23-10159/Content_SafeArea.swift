//
//  Content_SafeArea.swift
//  WWDC23-10159
//
//  Created by Catherine on 2023/6/17.
//

import SwiftUI

struct Content_SafeArea: View {
    @State var items: [Item] = (1 ..< 50).map { Item(id: $0) }
    @State private var flashTrigger = false
    
    var body: some View {
        ScrollView(.vertical) {
//            Button("Flash") {
//                flashTrigger.toggle()
//            }
            LazyVStack {
                ForEach(items) { item in
                    ColorItemView(item: item)
                }
            }
        }
        .scrollIndicatorsFlash(onAppear: true)
        .scrollIndicatorsFlash(trigger: flashTrigger)
        .scrollTargetBehavior(GalleryScrollTargetBehavior())

//        .safeAreaPadding(.vertical, 50.0)
//        
//        .safeAreaInset(edge: .top) {
//            RoundedRectangle(cornerRadius: 10)
//                .fill(Color.red)
//                .padding(.horizontal, 10)
//                .frame(height: 50)
//        }
//
//        .contentMargins (
//            .vertical, 50.0,
//            for: .scrollIndicators
//        )
    }
}

/// 自定义滚动Target行为
struct GalleryScrollTargetBehavior: ScrollTargetBehavior {
    func updateTarget(_ target: inout ScrollTarget, context: TargetContext) {
        print("velocity.dy: \(context.velocity.dy)")
        if target.rect.minY < (context.containerSize.height / 3.0),
           context.velocity.dy < 0.0 // 用 iOS17 beta2 模拟器测试
        {
            target.rect.origin.y = 0.0
        }
    }
}

struct ColorItemView: View {
    var item: Item

    var body: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(Color.blue)
            .padding(.horizontal, 10)
            .frame(height: 150)
    }
}

#Preview {
    Content_SafeArea()
}
