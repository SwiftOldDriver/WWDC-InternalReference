//
//  Content_Clip.swift
//  WWDC23-10159
//
//  Created by Catherine on 2023/6/18.
//

import SwiftUI

struct Content_Clip: View {
    let colors: [Color] = [.red, .green, .blue, .mint, .teal]
    
    var body: some View {
        VStack(spacing: 80) {
            ScrollView(.horizontal) {
                HStack(spacing: 20) {
                    ForEach(colors, id: \.self) { color in
                        Rectangle()
                            .frame(width: 100, height: 100)
                            .clipShape(TriangleShape())
                            .foregroundStyle(color)
                            .shadow(color: .primary, radius: 20)
                    }
                }
            } // ①不会触发离屏渲染
            
            ScrollView(.horizontal) {
                HStack(spacing: 20) {
                    ForEach(colors, id: \.self) { color in
                        Rectangle()
                            .frame(width: 100, height: 100)
                            .clipShape(TriangleShape())
                            .foregroundStyle(color)
                            .shadow(color: .primary, radius: 20)
                    }
                }
            }
            .scrollClipDisabled(true) // ②不会触发离屏渲染
            
            ScrollView(.horizontal) {
                HStack(spacing: 20) {
                    ForEach(colors, id: \.self) { color in
                        Rectangle()
                            .frame(width: 100, height: 100)
                            .clipShape(TriangleShape())
                            .foregroundStyle(color)
                            .shadow(color: .primary, radius: 20)
                    }
                }
            }
            .blur(radius: 10) // ③会触发离屏渲染
        } 
    }
}

struct TriangleShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.closeSubpath()
        return path
    }
}

#Preview {
    Content_Clip()
}
