//
//  WWDC23_10159App.swift
//  WWDC23-10159
//
//  Created by Catherine on 2023/6/18.
//

import SwiftUI

@main
struct WWDC23_10159App: App {
    var body: some Scene {
        WindowGroup {
//            Content_ScrollBasic() // 基础介绍
//            Content_SafeArea() // 安全区域
            Content_Featured() // 主要特性
//            Content_Clip() // 裁剪
        }
    }
}
