//
//  Content_More.swift
//  WWDC23-10159
//
//  Created by Catherine on 2023/7/2.
//

import SwiftUI

struct Content_More: View {
    @State private var scrollOffset: CGPoint = .zero
    
    var body: some View {
        NavigationView {
            ScrollView(.vertical) {
                ZStack(alignment: .top) {
                    ScrollViewOffsetTracker()
                    // Insert scroll view content here
                    LazyVStack {
                        ForEach(0..<100) { index in
                            Text("\(index)")
                                .frame(height: 40)
                        }
                    }
                }
            }
            .withOffsetTracking(action: {
                scrollOffset = $0
            })
            .navigationTitle(String(format: "Offset.y: %.0f", scrollOffset.y))
        }
        
        
//        NavigationView {
//            ScrollView(.vertical, showsIndicators: false) {
//                LazyVStack(spacing: 8, pinnedViews: [.sectionHeaders]) {
//                    Section(header: stickyHeaderView) {
//                        ForEach(0..<100) { index in
//                            Text("Item \(index)")
//                                .frame(height: 40)
//                        }
//                    }
//                }
//            }
//            .navigationTitle("Sticky Header")
//        }
    }
    
    var stickyHeaderView: some View {
        Rectangle()
            .fill(Color.blue)
            .frame(height: 50)
    }
}

enum ScrollOffsetNamespace {
    static let namespace = "scrollView"
}

struct ScrollOffsetPreferenceKey: PreferenceKey {
    
    static var defaultValue: CGPoint = .zero
    static func reduce(value: inout CGPoint, nextValue: () -> CGPoint) {}
}

struct ScrollViewOffsetTracker: View {
    var body: some View {
        GeometryReader { geo in
            Color.clear
                .preference(
                    key: ScrollOffsetPreferenceKey.self,
                    value: geo.frame(in: .named(ScrollOffsetNamespace.namespace)).origin
                )
        }
        .frame(height: 0)
    }
}

private extension ScrollView {
    func withOffsetTracking(
        action: @escaping (_ offset: CGPoint) -> Void
    ) -> some View {
        self.coordinateSpace(name: ScrollOffsetNamespace.namespace)
            .onPreferenceChange(ScrollOffsetPreferenceKey.self, perform: action)
    }
}

#Preview {
    Content_More()
}
