//
//  Content_Featured.swift
//  WWDC23-10159
//
//  Created by Catherine on 2023/6/16.
//

import SwiftUI

struct Palette: Identifiable {
    var id: UUID
    var name: String
}

struct Content_Featured: View {
    @State var palettes: [Palette] = [
        .init(id: UUID(), name: "Example One"),
        .init(id: UUID(), name: "Example Two"),
        .init(id: UUID(), name: "Example Three"),
        .init(id: UUID(), name: "Example Four"),
        .init(id: UUID(), name: "Example Five"),
        .init(id: UUID(), name: "Example Six"),
    ]
    @State var mainID: Palette.ID? = nil

    var body: some View {
        ScrollView {
            GalleryHeroContent(palettes: palettes, mainID: $mainID)
        }
    }
}

struct GalleryHeroContent: View {
    var palettes: [Palette]
    @Binding var mainID: Palette.ID?
    
    var body: some View {
        VStack {
            GalleryHeroHeader(palettes: palettes, mainID: $mainID)
            ScrollView(.horizontal) {
                LazyHStack(spacing: hSpacing) {
                    ForEach(palettes) { palette in
                        GalleryHeroView(palette: palette)
                    }
                }
                .scrollTargetLayout()
            }
            .contentMargins(.horizontal, hMargin)
            .scrollTargetBehavior(.viewAligned)
            .scrollPosition(id: $mainID)
            .scrollIndicators(.never)
        }
    }
    
    var hMargin: CGFloat {
#if os(macOS)
        40.0
#else
        20.0
#endif
    }

    var hSpacing: CGFloat {
        10.0
    }
}

struct GalleryHeroView: View {
    var palette: Palette

    @Environment(\.horizontalSizeClass) private var sizeClass

    var body: some View {
//        blueColorStack
//            .aspectRatio(16.0 / 9.0, contentMode: .fit)
//            .containerRelativeFrame(
//                [.horizontal],
//                count: sizeClass == .regular ? 2 : 1,
//                spacing: 10.0
//            )

        colorStack
            .aspectRatio(heroRatio, contentMode: .fit)
            .containerRelativeFrame(
                [.horizontal], count: columns, spacing: hSpacing
            )
            .clipShape(.rect(cornerRadius: 20.0))
            .scrollTransition(axis: .horizontal) { content, phase in
                content
                    .scaleEffect(
                        x: phase.isIdentity ? 1.0 : 0.75,
                        y: phase.isIdentity ? 1.0 : 0.75
                    )
//                    .rotationEffect(
//                        .degrees(phase.isIdentity ? 0.0 : 90.0)
//                    )
//                    .offset(
//                        x: phase.isIdentity ? 0.0 : 20.0,
//                        y: phase.isIdentity ? 0.0 : 20.0
//                    )
//                    .font(phase.isIdentity ? .body : .title2) // 报错
            }
    }

    private var columns: Int {
        sizeClass == .compact ? 1 : regularCount
    }

    @ViewBuilder
    private var colorStack: some View {
        let offsetValue = stackPadding
        ZStack {
            Color.red
                .offset(x: offsetValue, y: offsetValue)
            Color.blue
            Color.green
                .offset(x: -offsetValue, y: -offsetValue)
//            Text(palette.name)
//                .font(.system(size: 50))
        }
        .padding(stackPadding)
        .background()
    }

    @ViewBuilder
    private var blueColorStack: some View {
        ZStack {
            Color.blue
        }
        .background()
        .cornerRadius(10)
    }

    var stackPadding: CGFloat {
        20.0
    }

    var heroRatio: CGFloat {
        16.0 / 9.0
    }

    var regularCount: Int {
        2
    }

    var hSpacing: CGFloat {
        10.0
    }
}

struct GalleryHeroHeader: View {
    var palettes: [Palette]
    @Binding var mainID: Palette.ID?

    var body: some View {
        VStack(alignment: .leading, spacing: 2.0) {
            Text("Featured")
#if os(macOS)
            Text(palettes.first(where: { $0.id == mainID })?.name ?? "123")
                .font(.callout)
#endif
            Spacer().frame(maxWidth: .infinity)
        }
        .padding(.horizontal, hMargin)
#if os(macOS)
        .overlay {
            HStack(spacing: 0.0) {
                GalleryPaddle(edge: .leading) {
                    scrollToPreviousID()
                }
                Spacer().frame(maxWidth: .infinity)
                GalleryPaddle(edge: .trailing) {
                    scrollToNextID()
                }
            }
        }
#endif
    }

    private func scrollToNextID() {
        guard let id = mainID, id != palettes.last?.id,
              let index = palettes.firstIndex(where: { $0.id == id })
        else { return }

        withAnimation {
            mainID = palettes[index + 1].id
        }
    }

    private func scrollToPreviousID() {
        guard let id = mainID, id != palettes.first?.id,
              let index = palettes.firstIndex(where: { $0.id == id })
        else { return }
        
        withAnimation {
            mainID = palettes[index - 1].id
        }
    }
    
    var hMargin: CGFloat {
#if os(macOS)
        40.0
#else
        20.0
#endif
    }
}

#Preview {
    Content_Featured()
}
